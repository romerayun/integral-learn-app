



























<div class="offcanvas offcanvas-end" id="add-new-record" aria-modal="true" role="dialog">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title">Новая тема</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <form class="add-new-record pt-0 row g-2" id="form-add-new-theme">
            <?php echo csrf_field(); ?>

            <div class="col-sm-12 mt-3">
                <label class="switch align-items-center">
                    <input type="checkbox" class="switch-input switch-show" name="isExisting">
                    <span class="switch-toggle-slider">
                        <span class="switch-on"></span>
                        <span class="switch-off"></span>
                      </span>
                    <span class="switch-label">Добавить существующую тему</span>
                </label>
            </div>

            <div class="col-sm-12 mt-3 d-none" id="select-theme">
                <div>
                    <label for="theme_id" class="form-label">Выберите тему<sup class="text-danger">*</sup></label>
                    <select id="theme_id" name="theme_id" class="select2 form-select <?php if($errors->has('theme_id')): ?> is-invalid <?php endif; ?>">
                        <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?>

                                <?php if(count($item->learningPrograms)): ?>
                                    (Уч. программа(ы) -
                                    <?php $__currentLoopData = $item->learningPrograms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $learningProgram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($learningProgram->name); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    )
                                <?php endif; ?>
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="form-text text-danger">
                        <?php if($errors->has('theme_id')): ?>
                            <?php $__currentLoopData = $errors->get('theme_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>


            <div class="col-sm-12 mt-3" id="name-theme">
                <label class="form-label" for="name">Наименование</label>
                <div>
                    <input type="text" id="name" class="form-control name" name="name" placeholder="Техническая документация...">
                </div>
            </div>

            <div class="col-sm-12 mt-3">
                <button type="submit" class="btn btn-success me-sm-2 me-1">Сохранить</button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">Отмена</button>
            </div>
        </form>
    </div>
</div>

<div class="offcanvas offcanvas-end" id="edit-record" aria-modal="true" role="dialog">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title">Редактирование темы - <span></span></h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <form class="edit-record pt-0 row g-2" id="form-edit-theme">
            <?php echo csrf_field(); ?>
            <div class="col-sm-12">
                <label class="form-label" for="name">Наименование</label>
                <div>
                    <input type="text" id="name" class="form-control name" name="name" placeholder="Техническая документация...">
                    <input type="hidden" id="name-hidden">
                    <input type="hidden" id="theme-id">
                </div>
            </div>

            <div class="col-sm-12 mt-3">
                <button type="submit" class="btn btn-success me-sm-2 me-1">Сохранить</button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">Отмена</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/learning-programs/alerts.blade.php ENDPATH**/ ?>