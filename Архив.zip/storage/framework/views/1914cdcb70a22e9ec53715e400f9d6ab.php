<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление / <a class="text-muted" href="<?php echo e(route('learning-programs.index')); ?>">Учебные программы</a> / <a class="text-muted" href="<?php echo e(route('learning-programs.show', ['learning_program' => $activity->themes[0]->learningPrograms[0]->id])); ?>"><?php echo e($activity->themes[0]->learningPrograms[0]->name); ?></a> / </span>Активность</h4>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex mb-4">
                <a href="<?php echo e($url ?? old('url') ?? url()->previous()); ?>" class="btn btn-primary">
                    <span class="tf-icons bx bx-arrow-back"></span>&nbsp; Назад
                </a>
            </div>


            <div class="card mb-4">
                <h5 class="card-header pb-2">Редактирование активности</h5>
                <div class="card-body">
                    <form action="<?php echo e(route('activity.update', ['activity' => $activity->id])); ?>" method="POST" class="quill-form" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="url" value="<?php echo e($url ?? old('url') ?? url()->previous()); ?>">
                        <input type="hidden" name="theme_id" value="0">
                        <div class="row mt-2">

                            <div class="col-lg-12 col-md-12">
                                <div>
                                    <label for="type_id" class="form-label">Выберите тип активности<sup class="text-danger">*</sup></label>
                                    <select id="type_id" name="type_id" class="select2 form-select <?php if($errors->has('type_id')): ?> is-invalid <?php endif; ?>">
                                        <?php $__currentLoopData = $activityTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($activity->type_id == $item->id): ?>
                                                <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('type_id')): ?>
                                            <?php $__currentLoopData = $errors->get('type_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row mt-3">
                            <div class="col-md-12 col-lg-6">
                                <div>
                                    <label for="name" class="form-label">Наименование активности <sup class="text-danger">*</sup></label>
                                    <input type="text" class="form-control <?php if($errors->has('name')): ?> is-invalid <?php endif; ?>" name="name" id="name" placeholder="Введение" value="<?php echo e($activity->name); ?>" required>
                                    <div class="form-text text-danger" >
                                        <?php if($errors->has('name')): ?>
                                            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-6">
                                <div>
                                    <label for="count_hours" class="form-label">Введите количество часов<sup class="text-danger">*</sup> <span class="text-info"> (1 ак. час = 45 минут)</span></label>
                                    <input type="number" class="form-control <?php if($errors->has('count_hours')): ?> is-invalid <?php endif; ?>" name="count_hours" id="count_hours" placeholder="2" value="<?php echo e($activity->count_hours); ?>" step="1" min="1" required>
                                    <div class="form-text text-danger" >
                                        <?php if($errors->has('count_hours')): ?>
                                            <?php $__currentLoopData = $errors->get('count_hours'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col">
                                <label for="content" class="form-label">Контент активности</label>
                                <div class="quill"><?php echo $activity->content; ?></div>
                                <input type="hidden" name="content" id="quill-html" value="<?php echo $activity->content; ?>">
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col">
                                <button type="submit" class="btn btn-success">Сохранить</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/activity/update.blade.php ENDPATH**/ ?>