<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление /</span> Редактор теста</h4>

    <div class="row">
        <div class="col-md-12">

            <div class="card mb-4 mt-4">

                <div id="sticky-wrapper" class="sticky-wrapper">
                    <div class="card-header sticky-element bg-label-secondary d-flex justify-content-sm-between align-items-sm-center flex-column flex-sm-row">
                        <h5 class="card-title mb-sm-0 me-2">Редактор теста</h5>
                        <div class="action-btns">


                            <a href="<?php echo e($url ?? old('url') ?? url()->previous()); ?>" class="btn btn-label-primary me-2">
                                <span class="tf-icons bx bx-arrow-back"></span>&nbsp; Назад
                            </a>


                            <a class="new-question btn btn-primary text-white me-2">
                                <i class="tf-icons bx bx-plus me-1"></i> Добавить вопрос
                            </a>

                            <a class="btn btn-success text-white" id="store-quiz">
                                <i class="tf-icons bx bx-save me-1"></i> Сохранить изменения
                            </a>

                        </div>
                    </div>
                </div>

                <div class="card-body">

                        <input type="hidden" name="url" value="<?php echo e($url ?? old('url') ?? url()->previous()); ?>">
                        <input type="hidden" id="activity" value="<?php echo e($id); ?>">



                        <ol class="list-group list-group-numbered questions-content">

                            <?php if(count($questions) != 0): ?>
                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                    <li class="list-group-item border-none question" attr-number="<?php echo e($question->id); ?>" attr-time="old" attr-type="<?php echo e($question->type); ?>">
                                        <div class="d-flex align-items-center gap-3 ms-2">
                                            <input class="form-control" type="text"  placeholder="Введите вопрос..." value="<?php echo e($question->text_question); ?>" attr-val="<?php echo e($question->text_question); ?>">
                                            <div class="controls d-flex align-items-center gap-3 flex-shrink-0">
                                                <?php if(!$question->image): ?>
                                                    <form id="form-file<?php echo e($numberQuestion); ?>">
                                                        <input type="file" name="file<?php echo e($numberQuestion); ?>" id="file<?php echo e($numberQuestion); ?>" class="file-upload" accept="image/*" data-multiple-caption="{count} files selected">
                                                        <label for="file<?php echo e($numberQuestion); ?>" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Загрузить файл"><i class="tf-icons bx bx-upload"></i><span></span></label>
                                                    </form>
                                                <?php else: ?>
                                                    <a class="delFile d-flex flex-shrink-0 align-items-center gap-1 text-danger" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Удалить файл" ><i class="tf-icons bx bx-x-circle"></i> <span>Файл загружен </span></a>
                                                <?php endif; ?>
                                                <a class="del-question" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Удалить вопрос">
                                                    <i class="tf-icons bx bx-trash"></i>
                                                </a>
                                            </div>
                                        </div>

                                        <ul class="answers">
                                            <div class="answers-content">
                                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($answer->isCorrect == 1): ?>
                                                    <?php $checked = 'checked'; ?>
                                                <?php else: ?>
                                                    <?php $checked = ''; ?>
                                                <?php endif; ?>

                                                <?php $type = 'checkbox' ?>
                                                <?php if($question->type === 'r'): ?> <?php $type = 'radio' ?> <?php endif; ?>

                                                <li attr-id="<?php echo e($answer->id); ?>">
                                                    <div class="input_el d-flex align-items-center gap-2">
                                                        <input class="form-check-input" type="<?php echo e($type); ?>" name="el<?php echo e($question->id); ?>" <?php echo e($checked); ?> attr-check="<?php echo e($checked); ?>" >
                                                        <input type="text" class="form-control form-control-sm" placeholder="Введите ответ..." value="<?php echo e($answer->answer); ?>" attr-val="<?php echo e($answer->answer); ?>">
                                                        <div class="controls">
                                                            <a class="del-answer" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Удалить ответ">
                                                                <i class="tf-icons bx bx-trash"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                                <div class="d-flex mt-3 mb-2">
                                                    <a class="new-answer btn btn-sm btn-primary text-white me-2"><i class="tf-icons bx bx-plus me-1"></i> Добавить ответ</a>
                                                    <a class="change-type btn btn-sm btn-primary text-white" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Изменение типа на множественный или одиночный выбор ответа"><i class="tf-icons bx bx-refresh me-1"></i> Изменить тип вопроса</a>
                                                </div>
                                        </ul>
                                    </li>



                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>


                                <li class="list-group-item border-none question" attr-number="<?php echo e($numberQuestion); ?>">
                                    <div class="d-flex align-items-center gap-3 ms-2">
                                        <input class="form-control" type="text"  placeholder="Введите вопрос...">
                                        <div class="controls d-flex align-items-center gap-3">
                                            <form id="form-file<?php echo e($numberQuestion); ?>">
                                                <input type="file" name="file<?php echo e($numberQuestion); ?>" id="file<?php echo e($numberQuestion); ?>" class="file-upload" accept="image/*" data-multiple-caption="{count} files selected">
                                                <label for="file<?php echo e($numberQuestion); ?>" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Загрузить файл"><i class="tf-icons bx bx-upload"></i><span></span></label>
                                            </form>
                                            <a class="del-question" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Удалить вопрос">
                                                <i class="tf-icons bx bx-trash"></i>
                                            </a>
                                        </div>
                                    </div>

                                    <ul class="answers">
                                        <div class="answers-content">
                                            <li>
                                                <div class="input_el d-flex align-items-center gap-2">
                                                    <input class="form-check-input" type="checkbox" name="el<?php echo e($numberQuestion); ?>">
                                                    <input type="text" class="form-control form-control-sm" placeholder="Введите ответ...">
                                                    <div class="controls">
                                                        <a class="del-answer" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Удалить ответ">
                                                            <i class="tf-icons bx bx-trash"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="input_el d-flex align-items-center gap-2">
                                                    <input class="form-check-input" type="checkbox" name="el<?php echo e($numberQuestion); ?>">
                                                    <input type="text" class="form-control form-control-sm" placeholder="Введите ответ...">
                                                    <div class="controls">
                                                        <a class="del-answer" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Удалить ответ">
                                                            <i class="tf-icons bx bx-trash"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </li>

                                        </div>
                                        <div class="d-flex mt-3 mb-2">
                                            <a class="new-answer btn btn-sm btn-primary text-white me-2"><i class="tf-icons bx bx-plus me-1"></i> Добавить ответ</a>
                                            <a class="change-type btn btn-sm btn-primary text-white" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Изменение типа на множественный или одиночный выбор ответа"><i class="tf-icons bx bx-refresh me-1"></i> Изменить тип вопроса</a>
                                        </div>
                                    </ul>
                                </li>

                            <?php endif; ?>

                        </ol>



                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/quiz/construct.blade.php ENDPATH**/ ?>