<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление /</span> Пользователи</h4>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex mb-4">
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">
                    <span class="tf-icons bx bx-arrow-back"></span>&nbsp; Назад
                </a>
            </div>

            <div class="card mb-4">
                <h5 class="card-header pb-2">Добавление нового пользователя</h5>
                <p class="text-primary ms-4 me-4 mb-0">Для всех новых пользователей будет установлен пароль - 12345, данный пароль можно будет поменять в личном кабинете</p>
                <div class="card-body">
                    <form action="<?php echo e(route('users.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>


                        <div class="row">
                            <div class="col-12">

                                    <div class="form-check">
                                        <input name="role_id" class="form-check-input" value="1" type="radio" checked>
                                        <label class="form-check-label" for="role">
                                            Администратор
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input name="role_id" class="form-check-input" value="2" type="radio">
                                        <label class="form-check-label" for="role">
                                            Преподаватель
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input name="role_id" class="form-check-input" value="3" type="radio">
                                        <label class="form-check-label" for="role">
                                            Студент
                                        </label>
                                    </div>

                            </div>
                        </div>


                        <div class="row mt-3">
                            <div class="col-md-12 col-lg-4">
                                <div>
                                    <label for="surname" class="form-label">Фамилия <sup class="text-danger">*</sup></label>
                                    <input type="text" class="form-control <?php if($errors->has('surname')): ?> is-invalid <?php endif; ?>" name="surname" id="surname" placeholder="Иванов" value="<?php echo e(old('surname')); ?>">
                                    <div class="form-text text-danger" >
                                        <?php if($errors->has('surname')): ?>
                                            <?php $__currentLoopData = $errors->get('surname'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-4">
                                <div>
                                    <label for="name" class="form-label">Имя <sup class="text-danger">*</sup></label>
                                    <input type="text" class="form-control <?php if($errors->has('name')): ?> is-invalid <?php endif; ?>" name="name" id="name" placeholder="Иван" value="<?php echo e(old('name')); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('name')): ?>
                                            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-4">
                                <div>
                                    <label for="patron" class="form-label">Отчество <sup class="text-danger">*</sup></label>
                                    <input type="text" class="form-control <?php if($errors->has('patron')): ?> is-invalid <?php endif; ?>" name="patron" id="patron" placeholder="Иванович" value="<?php echo e(old('patron')); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('patron')): ?>
                                            <?php $__currentLoopData = $errors->get('patron'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row mt-2">
                            <div class="col-lg-4 col-md-12">
                                <div>
                                    <label for="series_passport" class="form-label">Серия паспорта <sup class="text-danger">*</sup></label>
                                    <input type="text" class="form-control <?php if($errors->has('series_passport')): ?> is-invalid <?php endif; ?>" name="series_passport" id="series_passport" placeholder="XXXX" value="<?php echo e(old('series_passport')); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('series_passport')): ?>
                                            <?php $__currentLoopData = $errors->get('series_passport'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12">
                                <div>
                                    <label for="number_passport" class="form-label">Номер паспорта <sup class="text-danger">*</sup></label>
                                    <input type="text" class="form-control <?php if($errors->has('number_passport')): ?> is-invalid <?php endif; ?>" name="number_passport" id="number_passport" placeholder="XXXXXX" value="<?php echo e(old('number_passport')); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('number_passport')): ?>
                                            <?php $__currentLoopData = $errors->get('number_passport'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12">
                                <div>
                                    <label for="date_of_birth" class="form-label">Дата рождения <sup class="text-danger">*</sup></label>
                                    <input type="text" placeholder="ГГГГ-ММ-ДД" class="form-control bs-datepicker-format <?php if($errors->has('date_of_birth')): ?> is-invalid <?php endif; ?>" name="date_of_birth" value="<?php echo e(old('date_of_birth', date("Y-m-d"))); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('date_of_birth')): ?>
                                            <?php $__currentLoopData = $errors->get('date_of_birth'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-6 col-md-12">
                                <div>
                                    <label for="snils" class="form-label">СНИЛС</label>
                                    <input type="text" class="form-control <?php if($errors->has('snils')): ?> is-invalid <?php endif; ?>" name="snils" id="snils" placeholder="XXX-XXX-XXX XX" value="<?php echo e(old('snils')); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('snils')): ?>
                                            <?php $__currentLoopData = $errors->get('snils'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div>
                                    <label for="phone" class="form-label">Номер телефона <sup class="text-danger">*</sup></label>
                                    <input type="text" class="form-control <?php if($errors->has('phone')): ?> is-invalid <?php endif; ?>" name="phone" id="phone" placeholder="+7(XXX)XXX-XX-XX" value="<?php echo e(old('phone')); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('phone')): ?>
                                            <?php $__currentLoopData = $errors->get('phone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-6 col-md-12">
                                <div>
                                    <label for="sex" class="form-label">Пол</label>
                                    <select id="sex" name="sex" class="select2 form-select <?php if($errors->has('sex')): ?> is-invalid <?php endif; ?>">
                                        <option value="M" <?php if(old('sex') == "M"): ?> selected <?php endif; ?>>Мужской</option>
                                        <option value="F" <?php if(old('sex') == "F"): ?> selected <?php endif; ?>>Женский</option>
                                    </select>
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('sex')): ?>
                                            <?php $__currentLoopData = $errors->get('sex'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div>
                                    <label for="country" class="form-label">Гражданство</label>
                                    <input type="text" class="form-control <?php if($errors->has('country')): ?> is-invalid <?php endif; ?>" name="country" id="country" placeholder="Россия" value="<?php echo e(old('country')); ?>">
                                    <input type="hidden" name="nationality" id="nationality" value="<?php echo e(old('nationality')); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('country')): ?>
                                            <?php $__currentLoopData = $errors->get('country'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col">
                                <button type="submit" class="btn btn-success">Сохранить</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/users/create.blade.php ENDPATH**/ ?>