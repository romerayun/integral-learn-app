<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление /</span> Учебные программы</h4>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex mb-4">
                <a href="<?php echo e(route('learning-programs.create')); ?>" class="btn btn-success">
                    <span class="tf-icons bx bx-plus"></span>&nbsp; Добавить
                </a>
            </div>


            <div class="card mb-4">
                <h5 class="card-header">Перечень учебных программ</h5>
                <div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <?php if($learningPrograms->isEmpty()): ?>
                            <p class="fw-bold">Учебных программ не найдено 😭</p>
                        <?php else: ?>
                            <table class="table table-hover table-sm" id="dataTable">
                                <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Наименование учебной программы</th>
                                    <th>Аннотация</th>
                                    <th>Рабочая программа</th>
                                    <th>Взаимодействие</th>
                                </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">

                                <?php $__currentLoopData = $learningPrograms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td>
                                            <?php echo e($item->name); ?>

                                        </td>
                                        <td>
                                            Аннотация учебной программы доступна в просмотре
                                        </td>
                                        <td>
                                            <?php if($item->working_program): ?>
                                                <a href="/storage/<?php echo e($item->working_program); ?>" download="Рабочая программа учебной программы - <?php echo e($item->name); ?>">Скачать</a>
                                            <?php else: ?>
                                                <span class="text-danger">Рабочая программа не добавлена</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="text-end">

                                                <a href="<?php echo e(route('learning-programs.edit', ['learning_program' => $item->id])); ?>" class="btn btn-sm btn-icon item-edit"><i class="bx bxs-edit"></i></a>

                                                <div class="d-inline-block">
                                                    <a  class="btn btn-sm btn-icon dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                        <i class="bx bx-dots-vertical-rounded"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-end m-0">
                                                        <li>
                                                            <a href="<?php echo e(route('learning-programs.show', ['learning_program' => $item->id])); ?>" class="dropdown-item"><span class="tf-icons bx bx-show"></span> Открыть</a>
                                                        </li>
                                                        <li>
                                                            <form action="<?php echo e(route('learning-programs.destroy', ['learning_program' => $item->id])); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="dropdown-item delete" data-bs-toggle="modal"
                                                                        data-bs-target="#modalCenter">
                                                                    <span class="tf-icons bx bx-trash"></span> Удалить
                                                                </button>
                                                            </form>
                                                        </li>
                                                    </ul>
                                                </div>





                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/learning-programs/index.blade.php ENDPATH**/ ?>