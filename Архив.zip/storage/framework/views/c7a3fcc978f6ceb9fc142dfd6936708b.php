<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление / <a class="text-muted" href="<?php echo e(route('users.index')); ?>">Пользователи</a> / </span>
        <?php echo e($user->getFullName()); ?></h4>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex mb-4">
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">
                    <span class="tf-icons bx bx-arrow-back"></span>&nbsp; Назад
                </a>
            </div>

            <div class="row">
                <div class="col-lg-4 col-md-12">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="user-avatar-section mt-3">
                                <div class=" d-flex align-items-center flex-column">
                                    <div class="user-info text-center">
                                        <h4 class="mb-2"><?php echo e($user->getFullName()); ?></h4>
                                        <span class="badge bg-label-<?php echo e($user->role->color); ?>"><?php echo e($user->role->name); ?></span>
                                    </div>
                                </div>
                            </div>

                            <h5 class="pb-2 border-bottom mb-4 mt-4">Информация о пользователе</h5>
                            <div class="info-container">
                                <ul class="list-unstyled">
                                    <li class="mb-3">
                                        <span class="fw-medium me-2">Паспортные данные:</span>
                                        <span><?php echo e($user->getPassport()); ?></span>
                                    </li>
                                    <li class="mb-3">
                                        <span class="fw-medium me-2">Дата рождения:</span>
                                        <span><?php echo e(\Carbon\Carbon::parse($user->date_of_birth)->format('d.m.Y')); ?></span>
                                    </li>
                                    <li class="mb-3">
                                        <span class="fw-medium me-2">Пол:</span>
                                        <span>
                                            <?php if($user->sex == 'M'): ?>
                                                Мужской
                                            <?php else: ?>
                                                Женский
                                            <?php endif; ?>
                                        </span>
                                    </li>
                                    <li class="mb-3">
                                        <span class="fw-medium me-2">СНИЛС:</span>
                                        <span>
                                            <?php if($user->snils): ?>
                                                <?php echo e($user->snils); ?>

                                            <?php else: ?>
                                                <span class="text-danger">Информация не заполнена</span>
                                            <?php endif; ?>
                                        </span>
                                    </li>
                                    <li class="mb-3">
                                        <span class="fw-medium me-2">Гражданство по коду ОКСМ:</span>
                                        <span>
                                            <?php if($user->nationality): ?>
                                                <?php echo e($user->nationality); ?>

                                            <?php else: ?>
                                                <span class="text-danger">Информация не заполнена</span>
                                            <?php endif; ?>
                                        </span>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/users/show.blade.php ENDPATH**/ ?>