<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <p>This is appended to the master sidebar.</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/welcome.blade.php ENDPATH**/ ?>