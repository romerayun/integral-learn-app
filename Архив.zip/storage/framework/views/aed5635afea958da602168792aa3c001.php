<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление /</span> Пользователи</h4>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex mb-4">
                <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success">
                    <span class="tf-icons bx bx-plus"></span>&nbsp; Добавить
                </a>
            </div>


            <div class="card mb-4">
                <h5 class="card-header">Список пользователей</h5>
                <div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <?php if($users->isEmpty()): ?>
                            <p class="fw-bold">Пользователей не найдено 😭</p>
                        <?php else: ?>
                            <table class="table table-sm table-hover" id="dataTable">
                                <thead>
                                <tr>
                                    <th>№</th>
                                    <th class="w-auto">Тип</th>
                                    <th>ФИО</th>
                                    <th>Паспорт</th>
                                    <th>Номер телефона</th>
                                    <th>Учебные группы</th>
                                    <th class="text-end">Взаимодействие</th>
                                </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">

                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td class="w-px-100">
                                            <span class="badge bg-<?php echo e($item->role->color); ?> fs-tiny">
                                                <?php echo e($item->role->name); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php echo e($item->getFullName()); ?>

                                        </td>
                                        <td><?php echo e($item->getPassport()); ?></td>
                                        <td>
                                            <a href="tel:<?php echo e($item->phone); ?>"><?php echo e($item->phone); ?></a>
                                        </td>
                                        <td>
                                            <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                                <?php if(count($item->groups)): ?>
                                                    <?php $__currentLoopData = $item->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" class="avatar avatar-xs pull-up bg-dark rounded-circle text-center shadow text-white text-uppercase" aria-label="<?php echo e($group->name); ?>" data-bs-original-title="<?php echo e($group->name); ?>" style="border: 2px solid #fff">
                                                            <?php echo e(mb_substr($group->name, 0 , 1, 'UTF-8')); ?>

                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <span class="text-danger">Пользователь не прикреплен ни к одной учебной группе</span>
                                                <?php endif; ?>


                                            </ul>

                                        </td>
                                        <td class="text-end">
                                            <div class="text-end">
                                                <a href="<?php echo e(route('users.edit', ['user' => $item->id])); ?>" class="btn btn-sm btn-icon item-edit"><i class="bx bxs-edit"></i></a>
                                                <div class="d-inline-block">
                                                    <a  class="btn btn-sm btn-icon dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                        <i class="bx bx-dots-vertical-rounded"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-end m-0">
                                                        <li>
                                                            <a href="<?php echo e(route('users.show', ['user' => $item->id])); ?>" class="dropdown-item"><span class="tf-icons bx bx-show"></span> Открыть</a>
                                                        </li>
                                                        <li>
                                                            <form action="<?php echo e(route('users.destroy', ['user' => $item->id])); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="dropdown-item text-danger delete-record delete" data-bs-toggle="modal"
                                                                        data-bs-target="#modalCenter">
                                                                    <span class="tf-icons bx bx-trash"></span> Удалить
                                                                </button>
                                                            </form>
                                                        </li>
                                                    </ul>
                                                </div>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/users/index.blade.php ENDPATH**/ ?>