<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление / <a class="text-muted" href="<?php echo e(route('groups.index')); ?>">Группы</a> / </span>  Добавление студентов</h4>

    <div class="d-flex mb-4">
        <a href="<?php echo e(route('groups.index')); ?>" class="btn btn-primary">
            <span class="tf-icons bx bx-arrow-back"></span>&nbsp; Назад
        </a>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <h5 class="card-header">Добавление студентов</h5>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('groups.add-user-store', ['group' => $id])); ?>">
                        <?php echo csrf_field(); ?>
                        <label for="learning_program" class="form-label">Выберите студентов для добавления в группу</label>
                        <div class="select2-primary">
                            <div class="position-relative">
                                <select id="users" required name="users[]"
                                        class="select2 form-select select2-hidden-accessible"
                                        multiple
                                        data-minimum-selection-length="1"
                                        data-placeholder="Выберите студентов">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>">
                                            <?php echo e($item->getFullName()); ?> (Паспортные данные: <?php echo e($item->getPassport()); ?>) - <?php echo e($item->role->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col">
                                <button type="submit" class="btn btn-success">Сохранить</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">

            <div class="card mb-4">
                <h5 class="card-header">Обучающиеся в группе - <?php echo e($group->name); ?></h5>
                <div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <?php if($group->users->isEmpty()): ?>
                            <p class="fw-bold">Студентов не найдено 😭</p>
                        <?php else: ?>
                            <table class="table table-hover table-sm">
                                <thead>
                                <tr>
                                    <th>№</th>
                                    <th>ФИО</th>
                                    <th>Паспортные данные</th>
                                    <th>Номер телефона</th>
                                    <th>Взаимодействие</th>
                                </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">

                                <?php $__currentLoopData = $group->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td>
                                           <?php echo e($item->getFullName()); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->getPassport()); ?>

                                        </td>
                                        <td>
                                            <a href="tel:<?php echo e($item->phone); ?>"><?php echo e($item->phone); ?></a>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <form action="<?php echo e(route('groups.destroy-group-user', ['group' => $item->id, 'id' => $item->pivot->id])); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn rounded-pill btn-icon btn-danger text-white delete" data-bs-toggle="modal"
                                                            data-bs-target="#modalCenter">
                                                        <span class="tf-icons bx bx-trash"></span>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/groups/add-user.blade.php ENDPATH**/ ?>