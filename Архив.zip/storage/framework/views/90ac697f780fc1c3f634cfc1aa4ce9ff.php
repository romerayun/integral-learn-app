<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление /</span> Группы</h4>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex mb-4">
                <a href="<?php echo e(route('groups.index')); ?>" class="btn btn-primary">
                    <span class="tf-icons bx bx-arrow-back"></span>&nbsp; Назад
                </a>
            </div>

            <div class="card mb-4">
                <h5 class="card-header pb-2">Добавление новой группы</h5>
                <p class="text-primary ms-4 me-4 mb-0">Каждую группу можно подписать на несколько учебных программ</p>
                <div class="card-body">
                    <form action="<?php echo e(route('groups.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>


                        <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div>
                                    <label for="name" class="form-label">Наименование учебной группы <sup
                                            class="text-danger">*</sup></label>
                                    <input type="text" class="form-control <?php if($errors->has('name')): ?> is-invalid <?php endif; ?>" required
                                           name="name" id="name" placeholder="Б-23-1" value="<?php echo e(old('name')); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('name')): ?>
                                            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <div class="row mt-2">
                            <div class="col-lg-6 col-md-12">
                                <div>
                                    <label for="start_date" class="form-label">Начало обучения <sup class="text-danger">*</sup></label>
                                    <input type="text" required placeholder="ГГГГ-ММ-ДД"
                                           class="form-control bs-datepicker-format <?php if($errors->has('start_date')): ?> is-invalid <?php endif; ?>"
                                           name="start_date" value="<?php echo e(old('start_date', date("Y-m-d"))); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('start_date')): ?>
                                            <?php $__currentLoopData = $errors->get('start_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div>
                                    <label for="end_date" class="form-label">Конец обучения <sup
                                            class="text-danger">*</sup></label>
                                    <input type="text" required placeholder="ГГГГ-ММ-ДД"
                                           class="form-control bs-datepicker-format <?php if($errors->has('end_date')): ?> is-invalid <?php endif; ?>"
                                           name="end_date" value="<?php echo e(old('end_date', date("Y-m-d"))); ?>">
                                    <div class="form-text text-danger">
                                        <?php if($errors->has('end_date')): ?>
                                            <?php $__currentLoopData = $errors->get('end_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($message); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <label for="learning_program" class="form-label">Учебные программа(-ы) <sup
                                    class="text-danger">*</sup></label>
                            <div class="select2-primary">
                                <div class="position-relative">
                                    <select id="learning_program" required name="learning_program[]"
                                            class="select2 form-select select2-hidden-accessible"
                                            multiple
                                            data-minimum-selection-length="1"
                                            data-placeholder="Выберите учебные программы">
                                        <?php $__currentLoopData = $learningPrograms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>">
                                                <?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col">
                                <button type="submit" class="btn btn-success">Сохранить</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/groups/create.blade.php ENDPATH**/ ?>