<?php $__env->startSection('content'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>

    <h4 class="fw-bold py-3 mb-0"><span class="text-muted fw-light">Управление / <a class="text-muted" href="<?php echo e(route('learning-programs.index')); ?>">Учебные программы</a> / </span>
        <?php echo e($lp->name); ?></h4>

    <div class="row">
        <div class="col-md-12">
            <div class="d-flex mb-4">
                <a href="<?php echo e(route('learning-programs.index')); ?>" class="btn btn-primary">
                    <span class="tf-icons bx bx-arrow-back"></span>&nbsp; Назад
                </a>
            </div>

            <input type="hidden" id="learning_program_id" value="<?php echo e($lp->id); ?>">

            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <div class="card card-action mb-4">
                        <div class="card-header">
                            <div class="card-action-title">Управление учебной программой</div>
                            <div class="card-action-element">
                                <ul class="list-inline mb-0">
                                    <li class="list-inline-item">
                                        <a href="javascript:void(0);" class="card-expand"><i class="tf-icons bx bx-fullscreen"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="d-flex mb-4 align-items-center gap-2 buttons-container">
                                <span>Добавить</span>
                                <a class="btn btn-label-secondary create-new">
                                    Тему
                                </a>
                                <?php if(count($lp->themes) != 0): ?>
                                    <a href="<?php echo e(route('activity.createActivity', ['learning_program' => $lp->id])); ?>" class="btn btn-label-secondary create-activity">
                                        Активность
                                    </a>
                                <?php endif; ?>
                            </div>

                            <div class="themes-container">


                                <?php if(count($lp->themes) == 0): ?>
                                    <input type="hidden" id="count-rows" value="0">
                                    <p class="fw-bold">Добавьте первую тему ☺️</p>
                                <?php endif; ?>
                                <?php $__currentLoopData = $lp->themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="card card-action mb-4 theme" id="theme<?php echo e($item->id); ?>">
                                    <div class="card-header">
                                        <div class="card-action-title">
                                            <div class="card-action-hours d-block fw-light"><?php echo e(getCountHoursTheme($item->id)); ?></div>
                                            <div class="card-action-name fw-bold" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></div>
                                        </div>
                                        <div class="card-action-element">
                                            <ul class="list-inline mb-0">

                                                <li class="list-inline-item">
                                                    <a href="<?php echo e(route('activity.createWithTheme', ['learning_program' => $lp->id, 'theme' => $item->id])); ?>" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Добавить активность"><i class="tf-icons bx bx-plus-circle"></i></a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <a class="edit-theme" attr-theme="<?php echo e($item->id); ?>" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Редактировать тему"><i class="tf-icons bx bx-pencil"></i></a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <a attr-theme="<?php echo e($item->id); ?>" class="delete-theme" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Удалить тему"><i class="tf-icons bx bx-trash"></i></a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <a href="javascript:void(0);" class="card-collapsible"><i class="tf-icons bx bx-chevron-up"></i></a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <div class="theme-handle">
                                                        <i class="tf-icons bx bx-move"></i>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="collapse show" style="">
                                        <div class="card-body pt-0">

                                            <div class="activities-container">
                                                <div class="empty-activity">+</div>
                                                <?php if(count($item->activities) != 0): ?>
                                                    <?php $__currentLoopData = $item->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <div class="card card-action mb-4 activity" id="activity<?php echo e($activity->id); ?>">
                                                        <div class="card-header">
                                                            <div class="card-action-title fw-bold"><?php echo e($activity->name); ?></div>
                                                            <div class="card-action-element">
                                                                <ul class="list-inline mb-0">

                                                                    <?php if(getIdTypeQuiz() == $activity->type_id): ?>
                                                                        <li class="list-inline-item">
                                                                            <a href="<?php echo e(route('quiz.construct', ['activity' => $activity->id])); ?>" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Редактор теста"><i class="tf-icons bx bx-customize"></i></a>
                                                                        </li>
                                                                    <?php endif; ?>
                                                                    <li class="list-inline-item">
                                                                        <a href="<?php echo e(route('activity.edit', ['activity' => $activity->id])); ?>" data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Редактировать активность"><i class="tf-icons bx bx-pencil"></i></a>
                                                                    </li>
                                                                    <li class="list-inline-item">
                                                                        <a attr-activity="<?php echo e($activity->id); ?>" class="delete-activity"  data-bs-toggle="tooltip"  data-bs-placement="top" data-bs-title="Удалить активность" ><i class="tf-icons bx bx-trash"></i></a>

                                                                    </li>
                                                                    <li class="list-inline-item">
                                                                        <a href="javascript:void(0);" class="card-collapsible"><i class="tf-icons bx bx-chevron-up"></i></a>
                                                                    </li>
                                                                    <li class="list-inline-item">
                                                                        <div class="activity-handle">
                                                                            <i class="tf-icons bx bx-move"></i>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="collapse show" style="">
                                                            <div class="card-body pt-0 pb-3">
                                                                <div class="d-flex fs-tiny align-items-center">
                                                                    <span class="badge bg-label-<?php echo e($activity->type->color); ?> activity-type"><?php echo e($activity->type->name); ?></span>
                                                                    <span class="activity-hours"><?php echo e($activity->count_hours); ?></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>



                                            </div>

                                        </div>
                                    </div>
                                </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                </div>
                <div class="col-lg-4 col-md-12"></div>
            </div>





        </div>
    </div>

    <?php echo $__env->make('manage.learning-programs.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romanyun/PhpstormProjects/integral-learn-app/resources/views/manage/learning-programs/show.blade.php ENDPATH**/ ?>