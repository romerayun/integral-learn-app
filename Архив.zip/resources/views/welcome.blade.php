@extends('layout.layout')

@section('content')
    @parent

    <p>This is appended to the master sidebar.</p>
@endsection

